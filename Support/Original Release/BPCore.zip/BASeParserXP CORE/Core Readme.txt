BASeParser XP Core Readme


